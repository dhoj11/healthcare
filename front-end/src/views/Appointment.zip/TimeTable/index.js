import { Modal } from "react-bootstrap";
import { useState } from "react";
import "./index.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import Appoint from "./Modal/Appoint/Appoint";
import Cancel from "./Modal/Cancel/Cancel";
import { getAppointList,getTestAppointment, getAppointTime, getPatientList, getTAppoint } from "./data/data";
import { useEffect } from "react";
import moment from "moment";
import { getTreatmentAppoint, getAppoint } from "../../../apis/appointment";
function TimeTable(props) {
  const {startDate,changeDate} = props;

  const [tAppointment,setTAppointment]= useState(getTAppoint());

  const [appointList,setAppointList] = useState(getAppointList);
  const [showAppointModal, setShowAppointModal] = useState(false);
  const [showCancelModal, setCancelModal]=useState(false);
  const [appointmentId,setappointmentId]= useState(38);
  const [appointInfo,setAppointInfo] = useState(null);
  const appointmentTime = getAppointTime();
  const [idx,setIdx] = useState({
    start:0,
    end:3
  });
  useEffect(() => {
    setIdx({
      start:0,
      end:3
    })
  },[tAppointment]);

  useEffect(() => {
    (async function() {
      try{
        const response =await getTreatmentAppoint(moment(startDate).format("YYYY-MM-DD"));
        const staffs =response.data.staffs;
        const doctorAppointment = response.data.doctorAppointment;
        
        let treatmentAppoint=[]
        for(let time of appointmentTime){
          let data = new Object();
          for(let i=0;i<staffs.length;i++){
            console.log(time);
            for(let item of doctorAppointment[i]){
                if(time === item.appointment_time){
                  data[staffs[i].staff_name] = item.appointment_id;
                }                
            }
            if(data[staffs[i].staff_name] ===undefined){
              data[staffs[i].staff_name] = null;
            }

          }
          treatmentAppoint.push(data);
        }
        console.log(treatmentAppoint)
        setTAppointment(treatmentAppoint);
        const res = await getAppoint(moment(startDate).format("YYYY-MM-DD"));
        console.log("resres",res.data);
        setAppointList(res.data);
      } catch(error){
        throw error;
      }
    })();
  },[startDate])
  const changeShow = (value) => {
    if(value === "TreatmentAppoint") {
      setTAppointment(getTAppoint());
    } else {
      setTAppointment(getTestAppointment());
    }
  };

  let btnNum=Math.ceil((Object.keys(tAppointment[0]).length)/4);


  
 

  console.log("렌더링횟수");
  const AppointModalClose = () => setShowAppointModal(false);
  const CancelModalClose = () => setCancelModal(false);
  const prevDate = () => {
    let date = new Date(startDate);
    date.setDate(date.getDate()-1);
    changeDate(date);
  }
  const nextDate = () => {
    let date = new Date(startDate);
    date.setDate(date.getDate()+1);
    changeDate(date);
  }
  
  const openModal = (time,doctor,value) => {
    const appointItem=appointList.filter(data => {
      return data.appointment_id === value
    })
    if(value==null || appointItem[0].appointment_state==="취소"){
      setShowAppointModal(true);
      setAppointInfo({
        time,
        doctor
      })
    } else if(appointItem[0].appointment_state==="예약" ){
      setAppointInfo({
        time,
        doctor,
        patient_name:appointItem[0].patient_name,
        appointment_content:appointItem[0].appointment_content,
        appointment_id:value
      });
      setCancelModal(true);
    }
    
  }

  const appoint = (Info) => {
    const patient = getPatientList().filter((data) => data.patient_id === Info.selectPatientId)[0];
    if(Info.selectPatientId!==""){
      
      setAppointList(
        appointList.concat({
          appointment_id:appointmentId,
          patient_id:patient.patient_id,
          patient_name:patient.patient_name,
          patient_gender:patient.patient_gender,
          appointment_state:"예약",
          appointment_content:Info.treatmentContent
        })
      )

      const newTimeTables = tAppointment.map((data,index) => {
        if(appointmentTime.indexOf(appointInfo.time) ===index){
          let newData= {...data, [appointInfo.doctor]:appointmentId};
          return newData;
        } else {
          return data;
        }
      });
      setTAppointment(newTimeTables);
      setappointmentId(appointmentId+1);
      setShowAppointModal(false);
    }

    
  }

  
  const appointCancel = () => {
    const newAppointList=appointList.map(data => {
      if(data.appointment_id === appointInfo.appointment_id){
        let newData = {...data, appointment_state:"취소"}
        return newData;
      } else {
        return data;
      }
    })
    setAppointList(newAppointList);
    setCancelModal(false);
  }
  const changeIdx = (i) => {
    let start;
    if(i===btnNum-1 && ((Object.keys(tAppointment[0]).length)%4)!==0){
      let remainNum=(Object.keys(tAppointment[0]).length)%4;
      start=i*4-(4-remainNum);
    }else {
      start=i*4;
    }
      let end = start+3;
      setIdx({
        start,
        end
      });
  }

  const treatmentAppoint = () => {
    changeIdx(0);
    changeShow("TreatmentAppoint");
  }
  const testAppoint = () => {
    changeIdx(0);
    changeShow("TestAppoint");
  }
  
  return(
    
    <div className="TimeTable_contain">
        <div className="date_contain d-flex justify-content-between">
          <div className ="showAppoint">
            <button onClick={treatmentAppoint}>진료</button>
            <button onClick={testAppoint}>검사</button>
          </div>
          <div className="d-flex">
            <button className="btn" onClick={prevDate}>{`<`}</button>
            <div className="date">{moment(startDate).format("YYYY-MM-DD")}</div> 
            <button className="btn" onClick={nextDate}>{`>`} </button>
          </div>
          <div className="number">
          {[...Array(btnNum)].map((n, index) => {
            if(Object.keys(tAppointment[0]).length >= 5){
              return (
                <button key={index} onClick={() => changeIdx(index)}>
                    {index+1}
                </button>
              )
            }
            
          })}
            </div>
        </div>
        
        <table className="TimeTable table">
          <thead>
            <tr>
              <th>시간</th>
              {Object.keys(tAppointment[0]).map((data,index) => {
                if(idx.start<=index && index<=idx.end){
                  return (
                    <th key={data}>{[data]} </th>
                  )
                }
              })}
            </tr>
          </thead>
          <tbody>
            {tAppointment.map((data,index) => {
              return (
              <tr key={index}>
                <td>{appointmentTime[index]}</td>

                {Object.values(data).map((value,i) => {
                  
                  if(idx.start<=i && i<=idx.end){
                    const appointItem= appointList.filter(appoint => value === appoint.appointment_id);

                 if(appointItem.length!==0){
                  const appointment = appointItem[0];
                  let state;
                  if(appointment.appointment_state==="진료완료" || appointment.appointment_state==="검사완료") {
                    state="complete";
                  }else if(appointment.appointment_state==="예약"){
                    state="appoint";
                  } else {
                    state="cancel";
                  }
                  
                  return (
                    <td 
                    key={i} 
                    onClick={() => openModal(appointmentTime[index],Object.keys(data)[i],value)} 
                    className={
                                state === "complete" ? "completeTd" :((state === "appoint") ? "appointTd" : "cancelTd")
                              }
                    >
                        <div>
                          <span>{appointment.patient_name}</span><span>({appointment.patient_gender})</span> <span className="stateStyle">{appointment.appointment_state}</span> 
                          <div>{appointment.appointment_content}</div>
                        </div>
                        
                      </td>
                  )
                  
                 } else {
                   if(appointmentTime[index] ==="13:00"){
                    return (<td key={i} className="lunch">{value}</td>);
                   }
                   else{
                      return (<td key={i} className="empty" onClick={() => openModal(appointmentTime[index],Object.keys(data)[i],value)}></td>);                    
                   }
                   
                 } 
                  }
                                  
                })}
              </tr>
              )
            })}
          </tbody>
        </table>
        <Modal
          show={showAppointModal} 
          onHide={AppointModalClose}
          size="lg"
          centered="true"
          >
            <Appoint AppointModalClose={AppointModalClose} appoint={appoint}></Appoint>
        </Modal>

        <Modal
          show={showCancelModal} 
          onHide={CancelModalClose}
          size="sm"
          centered="true"
          >
            <Cancel CancelModalClose={CancelModalClose} appointInfo={appointInfo} appointCancel={appointCancel}></Cancel>
        </Modal>
    </div>
    
    
  );
}
export default TimeTable;

